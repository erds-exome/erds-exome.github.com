from PreciseNonNegativeReal import *
from numpy import *

x = PreciseNonNegativeReal(0.01)
y = PreciseNonNegativeReal(0.001)
